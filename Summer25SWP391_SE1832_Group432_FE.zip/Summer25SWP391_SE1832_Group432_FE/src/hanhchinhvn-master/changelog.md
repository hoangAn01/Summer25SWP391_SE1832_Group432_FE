# Changelog

## 2023/04/08

### 1. Tỉnh Bắc Ninh

1. Huyện Quế Võ chuyển thành Thị xã. [1](https://dantri.com.vn/xa-hoi/le-cong-bo-nghi-quyet-thanh-lap-thi-xa-que-vo-20230407090859015.htm)
2. Huyện Thuận Thành chuyển thành Thị xã. [2](https://danviet.vn/dua-thi-xa-thuan-thanh-thuoc-tinh-bac-ninh-phat-trien-hien-dai-giau-ban-sac-van-hoa-20230405222541569.htm)

### 2. Tỉnh Bình Dương

1. Thị xã Tân Uyên chuyển thành Thành phố. [3](https://vnexpress.net/thanh-lap-thanh-pho-tan-uyen-thuoc-tinh-binh-duong-4570046.html)


### 3. Tỉnh An Giang

1. Huyện Tịnh Biên chuyển thành Thị xã. [4](https://baoangiang.com.vn/tinh-bien-vuon-minh-len-thi-xa-a356501.html)
